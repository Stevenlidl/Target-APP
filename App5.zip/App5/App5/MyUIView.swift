//
//  MyUIView.swift
//  App5
//
//  Created by Zixiang Li on 11/15/17.
//  Copyright © 2017 Zixiang Li. All rights reserved.
//

import UIKit
import AVFoundation

class MyUIView: UIView {

    @IBOutlet fileprivate var cannonball : UIImageView!
    @IBOutlet fileprivate var target : [UIImageView] = []    //Store the targets UIImageView
    @IBOutlet weak var ScoreLabel: UILabel!
    @IBOutlet weak var ShotLabel: UILabel!
    fileprivate var x : Int = 0                  ////Store the original x of canoon ball
    fileprivate var y : Int  = 0                 ////Store the original y of canoon ball
    fileprivate var cannon_x : Int = 0          //Store the canoon ball' x
    fileprivate var cannon_y : Int = 0          //Store the canoon ball' y
    fileprivate var cannon_touched = false     //To check whether the cannon_ball is touched
    private var  start_time = 0.0
    private var  end_time = 0.0
    private var  start_point : CGPoint!
    private var  end_point : CGPoint!
    private var check = false                 //Put in draw function to check whether the preset is done
    private var width : CGFloat = 0           //The width of UIView
    private var height : CGFloat = 0          //The height of UIView
    private var timer : Timer!
    private let PIX_M : CGFloat = 10
    private var velocity : CGFloat = 0   //Velocity
    private var t : CGFloat = 0      //Store the time
    private var alp : CGFloat = 0   //Store the angle
    private var x1 : [Int] = []    //Store the x for each target
    private var y1 : [Int] = []    //Store the y for each target
    private var touchedIndex : [Int] = []       //Store the index of target which is be touched
    private var score : Int = 0
    private var shot : Int = 0
    private var player = AVAudioPlayer()
    
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        self.width = UIScreen.main.bounds.size.width
        self.height = UIScreen.main.bounds.size.height
        self.x = Int(width/2 - 20)
        self.y = Int(height * 0.875 - 40)
        self.cannon_x = x
        self.cannon_y = y
    }

    override func awakeFromNib()
    {
        //Set Up background

        let img = UIImage(named: "bg2.png")
        self.backgroundColor = UIColor(patternImage: img!)
       // let url = URL(string: "target_hit.wav")
        let url = Bundle.main.url(forResource: "target_hit", withExtension: "wav")!
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player.prepareToPlay()
            
        } catch let error as NSError {
            print(error.description)
        }
        self.setNeedsDisplay()
    }
    
    override func draw(_ rect: CGRect)
    {

        // Preset
        if(check == false)
        {
        let imgt = UIImage(named: "touched.png")

        //I change the boundarie for the target
        let factor = CGFloat(0.8 - 30 / Float(height * 0.8))
        //Add all the targets
        for i in 0..<10
        {
            
            x1.append(Int(arc4random()) % Int(width * 0.9))
            y1.append(Int(arc4random()) % Int(height * factor) + 30)
            
            //Create UIImageView
            target.append(UIImageView(frame: CGRect(x: CGFloat(x1[i]), y: CGFloat(y1[i]), width: 40, height: 40)))
            
            target[i].image = imgt
            target[i].isHidden = false
        
    
            //Add the image to the view
            self.addSubview(target[i])
            
        }
          check = true
	
        }
        
        
        //Draw the cannon ball and other stuff
        self.cannonball.frame = CGRect(x: CGFloat(self.cannon_x), y: CGFloat(self.cannon_y), width: self.cannonball.frame.size.width, height: self.cannonball.frame.size.height);
        
        let ctx = UIGraphicsGetCurrentContext()
        ctx?.setFillColor(red: CGFloat(213/Float(255)), green: CGFloat(130/Float(255)), blue: CGFloat(50/Float(255)), alpha: 1.0);
        ctx?.fill(CGRect(x: self.center.x - 10, y: height * 0.875, width: 20, height: height*0.125));
        
        ctx?.setFillColor(red: 1, green: 1, blue: CGFloat(115/Float(255)), alpha: 1.0);
        ctx?.fill(CGRect(x: 0, y: height - 10, width: width, height: 10));

        
        //To check whether the target be touched
        if x1.count > 0 && cannon_touched
        {
        for i in 0..<x1.count
        {

        if (!touchedIndex.contains(i) && ((self.cannon_x > x1[i] - 40) && (self.cannon_x < x1[i] + 40) && ((self.cannon_y > y1[i] - 40) && (self.cannon_y < y1[i] + 40))))  //This place is wried!!!!!!!!!!!!!!!!!!!!!
        {
            //Replace the touched target to red
            target[i].removeFromSuperview()
            target[i].image = UIImage(named: "untouched.png")
            self.addSubview(target[i])
            touchedIndex.append(i)

            player.play()
            print("It works")
            
            score += 1           //Add the score by one
            ScoreLabel.text = "Score: \(score)"
          }
         }
        }
        
        //Remove the touched target
        if(!cannon_touched && !touchedIndex.isEmpty)
        {
            for i in touchedIndex
            {
                target[i].removeFromSuperview()
            }
            
            //If the targets is all gone call altercontroller
            
            if score >= 10
            {
                let alertController = UIAlertController(title: "You Win!", message: "Congratulation! Game is over. Press OK to restart the game. ", preferredStyle: .actionSheet)
                
                
                let OKAction = UIAlertAction(title: "OK", style: .default) { action in
                    self.restart()
                    // ...
                }
                alertController.addAction(OKAction)
                
                
                self.window?.rootViewController?.present(alertController, animated: true, completion: nil)
                
            }
        }

        ///////////////////////////////////////
        ////Preset done
        ///////////////////////////////
    }
    
    func restart()
    {

        
        //restart the game
        self.check = false
        self.cannon_x = Int(self.center.x-20)
        self.cannon_y = Int(height*0.875-40)
        self.shot = 0
        self.score = 0
        ScoreLabel.text = "Score: \(score)"
        ShotLabel.text = "Shots: \(shot)"
        target.removeAll()
        touchedIndex.removeAll()
        x1.removeAll()
        y1.removeAll()
        
        self.setNeedsDisplay()
    }

    func timerFired()
    {

        if (cannon_touched)
        {
            t += 0.25
            let ball_height = self.cannonball.frame.size.height
            let GRAVITY : CGFloat = 9.8
        

        if (cannon_y + Int(ball_height) > Int(self.bounds.size.height) || (cannon_x + Int(ball_height)) > Int(self.bounds.size.width) || cannon_y < 0 || cannon_x < 0)
        {
            cannon_y = y
            cannon_x = x
            timer.invalidate()
            cannon_touched = false
            t = 0
            self.setNeedsDisplay()
        }
            //I slow down the velocity since it too fast. Then user can trace the ball
        if cannon_touched{
            var temp = CGFloat(-velocity * abs(sin(alp)) * t)
            temp = temp + 0.5 * GRAVITY * t * t
            self.cannon_y = Int(temp * PIX_M)/10 + y
           if(end_point.x < start_point.x && end_point.y < start_point.y)
           {
           
            self.cannon_x = Int(-velocity * cos(alp) * t * PIX_M)/10 + x

            }
            else if(start_point.x < end_point.x && end_point.y < start_point.y)
           {
            self.cannon_x = Int(velocity * (cos(alp) * t) * PIX_M)/10 + x
            }

            
            self.setNeedsDisplay()
            }
        }
    }

    /////////////////////////////////////////////////////////////////////
    ////////////////
    /////////////////////////////////////////////////////////////////////
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        //Implement touches began here
        var all_touches = Array(touches)
        
        
        //Get all touches
        for i in 0..<all_touches.count
        {
            //Get the touch object
            let touch = all_touches[i] as! UITouch
            
            //print("Touch info in tap: \(touch)")
            

            
            //Display the location of the touch point
            //print("Touch occurred at \(touchPoint.x),\(touchPoint.y)")
            
            //Get the tap count
            let tap = touch.tapCount
            //print("Tap count is: \(tap)")
            
            //Get the touch
            let start_touch = all_touches[0]
            
            //Get the location
            start_point = start_touch.location(in: self)
            
            //Get the time
            start_time = start_touch.timestamp;

        }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        //cannon_touched = false;
        
        
    }
    
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        //Implement touches moved here
        
        var all_touches = Array(touches)
        
        //Display header
        //print("****************************************Touches MOVED***********")
        
        //print("Number of dragged touches: \(all_touches.count)");
        
        //Get all touches
        for i in 0..<all_touches.count
        {
            //Get the touch object
            let touch = all_touches[i] as! UITouch
            
            //print("Touch info in moved \(touch)");
            
            //Get the location where touch occurred
            let touchPoint = touch.location(in: self)
            
            
            
            
            if (cannon_touched == false && (Int(touchPoint.x) > x) && (Int(touchPoint.x) < x + 40) && (Int(touchPoint.y) > y) &&
                (Int(touchPoint.y) < y + 40))
            {
 
                ////
                let end_touch = all_touches[0]
                
                //Get the location
                end_point = end_touch.location(in: self)
                
                //Get the time
                end_time = end_touch.timestamp;
                let xside = start_point.x - end_point.x
                let yside = start_point.y - end_point.y
                let dist = CGFloat(sqrt(pow(xside,2.0)+pow(yside,2.0)))*(1.0/PIX_M);
                
                //To see whether user fire downward
                if yside > 0{
                    shot += 1
                    ShotLabel.text = "Shots: \(shot)"
                    alp = atan(yside/xside)
                    let delta_t = end_time - start_time;
                    self.velocity = dist/CGFloat(delta_t)
                    print("Velocity->\(velocity)")
                    timer = Timer.scheduledTimer(timeInterval: 0.025, target: self, selector: #selector(MyUIView.timerFired), userInfo: nil, repeats: true)
                    cannon_touched = true
                    print("Canoon touched")
                }

                
                
            }
            
        
            
            
            
            

            
//            if (cannon_touched == true)
//            {
//                x = Int(touchPoint.x) - Int(offset.x)
//                y = Int(touchPoint.y) - Int(offset.y)
//            }
            
            //Display the location of the touch point
            //print("Touch Dragged occurred at: \(touchPoint.x)  \(touchPoint.y)");
        }
    }

    
    
}
